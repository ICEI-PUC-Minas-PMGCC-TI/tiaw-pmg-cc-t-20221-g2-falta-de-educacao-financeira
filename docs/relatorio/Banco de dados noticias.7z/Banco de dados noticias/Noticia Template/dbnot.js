var db = {
    dados: [
        {
            titulo: 'Dólar cai forte e termina a semana em R$ 5,05; Ibovespa fecha em alta',
            corpo: 'No dia, o dólar caiu 1,61%, para R$ 5,0570, com baixa semanal de 0,36%. Já o Ibovespa subiu 1,17%, aos 106.924 mil pontos, na semana, o indicador registrou alta de 1,7%.',
            data: '13/05/2022',
            imagem: 'https://investnews.com.br/wp-content/uploads/2022/04/2022-04-05T120853Z_1_LYNXNPEI340K4_RTROPTP_4_DOLAR-ABRE-1536x1109.jpg',
            link: 'https://investnews.com.br/financas/ibovespa-dolar-cotacao-13-05-2022/',
        }, {
            titulo: 'Bitcoin pode marcar sequência recorde de baixas após colapso de stablecoins</h5> <span>Data: 13/05/2022',
            corpo: 'O bitcoin subia 5,5% às 12h22 (horário de Brasília), para US$ 30.464, encenando uma recuperação em relação à queda da véspera, quando chegou a operar no patamar de cerca de US$ 25.400.',
            data: '13/05/2022',
            imagem: 'https://investnews.com.br/wp-content/uploads/2022/04/bitcoin-dollar-1536x1024.jpg',
            link: 'https://investnews.com.br/criptonews/bitcoin-pode-marcar-sequencia-recorde-de-baixas-apos-colapso-de-stablecoins/',
        }, {
            titulo: 'Pesquisa aponta que 40% da população planeja usar saque do FGTS para quitar dívida',
            corpo: 'Novos saques do FGTS 2022 envolverão valores de até R$ 1 mil, e os primeiros a receber serão as pessoas com saldo no fundo nascidas em janeiro. Limpar o nome, se reorganizar financeiramente e voltar a ter condições de contrair novos empréstimos é o que quatro em cada dez brasileiros pretendem fazer com o dinheiro a que terão direito a sacar do Fundo de Garantia do Tempo de Serviço (FGTS) a partir desta quarta-feira (20).',
            data: '19/04/2022',
            imagem: 'https://www.cnnbrasil.com.br/wp-content/uploads/sites/12/2021/06/2582_C7B312AC007DF712-11.jpg?w=876&h=484&crop=1',
            link: 'https://www.cnnbrasil.com.br/business/40-da-populacao-pretende-usar-saque-do-fgts-para-quitar-divida-e-limpar-nome/',
        }, {
            titulo: 'Inter (BIDI11) salta 7% após aval dos acionistas para listagem na Nasdaq',
            corpo: 'As units do Inter (BIDI11) saltam 7,50% na bolsa nesta sexta-feira, 13, dia marcado pela recuperação dos papéis de tecnologia. Os ganhos do banco digital, no entanto, estão associados principalmente a uma novidade do próprio negócio.',
            data: '13/05/2022',
            imagem: 'https://logospng.org/wp-content/uploads/banco-inter.png',
            link: 'https://www.cnnbrasil.com.br/business/40-da-populacao-pretende-usar-saque-do-fgts-para-quitar-divida-e-limpar-nome/',
        }
    ]
}