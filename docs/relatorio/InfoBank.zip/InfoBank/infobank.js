var db = {
    dados: [
        {
            logo: 'https://wwfbr.awsassets.panda.org/img/original/banco_do_brasil_logo2.jpg',
            banco: 'Banco do Brasil',
            nome: 'Antonio C. Martins',
            saldo: 'R$ 629,13',
            agencia: '5718-0',
            conta: '35.278-8',
        }, {
            logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/8/8a/Banco_Ita%C3%BA_logo.svg/1200px-Banco_Ita%C3%BA_logo.svg.png',
            banco: 'Itaú',
            nome: 'Antonio C. Martins',
            saldo: 'R$ 2.859,56',
            agencia: '4824',
            conta: '0081027-6',
        }, {
            logo: 'https://store-images.microsoft.com/image/apps.59984.13510798883325079.34955a54-3d54-4153-91c4-ee68505d8859.ba13c6e6-99b0-4829-82bd-cc236edf8aa1?mode=scale&q=90&h=300&w=300',
            banco: 'Caixa Econômica Federal',
            nome: 'Antonio C. Martins',
            saldo: 'R$ 15.481,89',
            agencia: '027',
            conta: '00059836-2',
        }, {
            logo: 'https://files.tecnoblog.net/wp-content/uploads/2022/01/bradesco-logo.jpg',
            banco: 'Bradeso',
            nome: 'Antonio C. Martins',
            saldo: 'R$ 43,00',
            agencia: '3614',
            conta: '0062145-7',
        }, {
            logo: 'https://shoppingunisul.com.br/palhoca/wp-content/uploads/2019/02/santander.jpg',
            banco: 'Santander',
            nome: 'Antonio C. Martins',
            saldo: 'R$ 370,99',
            agencia: '1690',
            conta: '01006435-7',
        }
    ]
}