// const API_KEY = ''; chave não necessaria
/**
 API USADA - https://docs.coincap.io/
*/

function exibeDados(data) {
  let divScreen = document.getElementById("colocar");
  let texto = "";
  let dados = JSON.parse(data.target.responseText);
  let dados1 = dados.data;
  texto += `<div class="col-6"><a href="https://coinmarketcap.com/pt-br/"><img src="imgs/${dados1.id}.jpg" style="max-width:100px;"></a></div>
          <div class="col-6"><h5 class="titulo-investimento">${dados1.id}</h5> 
          <p class="corpo-investimento">Valor em Dólares: ${dados1.priceUsd}
          <br class="mudanca-investimento">Alteração (em %) do valor nas 24hrs: ${dados1.changePercent24Hr}</br></p></div>`;
  divScreen.innerHTML += texto;
}

let arrayM = [
  "monero",
  "ethereum",
  "litecoin",
  "dogecoin",
  "chainlink",
  "bitcoin"
];

function carregaDados() {
  //alert(`a.${moeda} , ${i}`);
  let xhr = new XMLHttpRequest();
  let xhr1 = new XMLHttpRequest();
  let xhr2 = new XMLHttpRequest();
  let xhr3 = new XMLHttpRequest();
  xhr.onload = exibeDados;
  let moeda = arrayM.pop();
  xhr.open("GET", `https://api.coincap.io/v2/assets/${moeda}`);
  xhr1.onload = exibeDados;
  moeda = arrayM.pop();
  xhr1.open("GET", `https://api.coincap.io/v2/assets/${moeda}`);
  xhr2.onload = exibeDados;
  moeda = arrayM.pop();
  xhr2.open("GET", `https://api.coincap.io/v2/assets/${moeda}`);
  xhr3.onload = exibeDados;
  moeda = arrayM.pop();
  xhr3.open("GET", `https://api.coincap.io/v2/assets/${moeda}`);
  xhr.send();
  xhr1.send();
  xhr2.send();
  xhr3.send();
}

var i = 0;
document.addEventListener("DOMContentLoaded", carregaDados());
