var db = {
    dados: [
        {
            nome: 'AMAZON',
            tipo: 'Tipo de investimento: ação',
            tempo: 'Tempo do gráfico: 1 mês',
            imagem: 'https://tvc-invdn-com.investing.com/data/tvc_cfeef18fa5efe4be9f6e733ab24e8e20.png',
            link: 'https://br.investing.com/equities/amazon.com-inc-bdr',
        }, {
            nome: 'APPLE',
            tipo: 'Tipo de investimento: ação',
            tempo: 'Tempo do gráfico: 1 mês',
            imagem: 'https://tvc-invdn-com.investing.com/data/tvc_811202eb587f10a9fa2a5eedade19622.png',
            link: 'https://br.investing.com/equities/apple-computer-inc-chart',
        }, {
            nome: 'DÓLAR',
            tipo: 'Tipo de investimento: moeda',
            tempo: 'Tempo do gráfico: 1 mês',
            imagem: 'https://cdn.discordapp.com/attachments/973743604495450192/975506641434865724/unknown.png',
            link: 'https://br.investing.com/crypto/bitcoin',
        }, {
            nome: 'BITCOIN',
            tipo: 'Tipo de investimento: criptomoeda',
            tempo: 'Tempo do gráfico: 1 mês',
            imagem: 'https://tvc-invdn-com.investing.com/data/tvc_f6b61f362c8b2b38b038b2e87e1ce937.png',
            link: 'https://br.investing.com/crypto/bitcoin',
        }
    ]
}